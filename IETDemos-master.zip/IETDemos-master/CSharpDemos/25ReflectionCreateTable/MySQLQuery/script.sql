Create table Employee ( EId int,EName varchar(50),EAddress varchar(50) );
