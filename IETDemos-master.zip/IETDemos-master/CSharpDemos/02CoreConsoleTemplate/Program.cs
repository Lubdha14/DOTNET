﻿namespace _02CoreConsoleTemplate
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i;
            Console.WriteLine("Hello, World!");
            Console.WriteLine();
        }
    }
}
